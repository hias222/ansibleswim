self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4dec58726725f65f984853849b1fc775",
    "url": "/admin/index.html"
  },
  {
    "revision": "fb2a7e86181b28c988d5",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "4f503997460c3181f604",
    "url": "/admin/static/js/2.07ffb4d7.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.07ffb4d7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fb2a7e86181b28c988d5",
    "url": "/admin/static/js/main.45368169.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);