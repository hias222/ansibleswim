self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c0c60993c25a6d17ef88545fc04372ff",
    "url": "/admin/index.html"
  },
  {
    "revision": "2999c4147df4544d26ca",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "7eb456b34d38c4e5afae",
    "url": "/admin/static/js/2.52e9dd30.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.52e9dd30.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2999c4147df4544d26ca",
    "url": "/admin/static/js/main.5edc80ef.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);