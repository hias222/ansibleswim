self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8fabeb345d733d5eb72c39bb215396fa",
    "url": "/admin/index.html"
  },
  {
    "revision": "88bb07ed024ff518e93f",
    "url": "/admin/static/css/main.9cf91c12.chunk.css"
  },
  {
    "revision": "e4aa38f3955dd50ffe2d",
    "url": "/admin/static/js/2.47ecc2da.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.47ecc2da.chunk.js.LICENSE.txt"
  },
  {
    "revision": "88bb07ed024ff518e93f",
    "url": "/admin/static/js/main.1f6cd408.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);