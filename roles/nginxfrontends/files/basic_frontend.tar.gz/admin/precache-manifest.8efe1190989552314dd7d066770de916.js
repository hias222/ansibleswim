self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5d9e24e96da3cdcd2e68c384717653e2",
    "url": "/admin/index.html"
  },
  {
    "revision": "952e4bb082dab814bd2e",
    "url": "/admin/static/css/main.aae5a0c2.chunk.css"
  },
  {
    "revision": "29638f4ba4559021b58b",
    "url": "/admin/static/js/2.9a2d64d3.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.9a2d64d3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "952e4bb082dab814bd2e",
    "url": "/admin/static/js/main.f9781e2c.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);