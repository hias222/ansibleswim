self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "35fed4aa6c487139588d44176314f76e",
    "url": "/admin/index.html"
  },
  {
    "revision": "c1137c21c3691961855c",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "dd8fad5a5d5521e8beae",
    "url": "/admin/static/js/2.89576fed.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.89576fed.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c1137c21c3691961855c",
    "url": "/admin/static/js/main.74c37d98.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);