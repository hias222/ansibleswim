self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c460dfc903e4890838cff9fa986ee4f8",
    "url": "/admin/index.html"
  },
  {
    "revision": "392e1578c988446914bc",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "51f54bb861b80f82bef3",
    "url": "/admin/static/js/2.1a9f76ea.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.1a9f76ea.chunk.js.LICENSE.txt"
  },
  {
    "revision": "392e1578c988446914bc",
    "url": "/admin/static/js/main.fbc23559.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);