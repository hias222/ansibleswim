self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dc62f3c843f10bad9e6eb4df641cd4a8",
    "url": "/admin/index.html"
  },
  {
    "revision": "758f3da1038c4d21b054",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "1f8e9bed8d9f2d70042d",
    "url": "/admin/static/js/2.f005e911.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.f005e911.chunk.js.LICENSE.txt"
  },
  {
    "revision": "758f3da1038c4d21b054",
    "url": "/admin/static/js/main.b4556a3a.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);