self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f9bd118dfaf8e7234f238e03c6408838",
    "url": "/admin/index.html"
  },
  {
    "revision": "c271b9679e50d7aab423",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "df5ba9647b3b42723418",
    "url": "/admin/static/js/2.0b1e70d6.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.0b1e70d6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c271b9679e50d7aab423",
    "url": "/admin/static/js/main.b7edf98e.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);