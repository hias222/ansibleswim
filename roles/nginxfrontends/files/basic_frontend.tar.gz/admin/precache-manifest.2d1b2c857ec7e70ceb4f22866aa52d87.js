self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c529a29b72da56f10ddee4ddc8837de6",
    "url": "/admin/index.html"
  },
  {
    "revision": "c78a3f20dd6fdd3d07a9",
    "url": "/admin/static/css/main.3beb7c71.chunk.css"
  },
  {
    "revision": "26ac59728e53a6e0c558",
    "url": "/admin/static/js/2.ef0863cd.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.ef0863cd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c78a3f20dd6fdd3d07a9",
    "url": "/admin/static/js/main.1106a3bb.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);