self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "61b0ffd56cc69d9ed49f49ce0000633c",
    "url": "/admin/index.html"
  },
  {
    "revision": "21daa3a09fe019439ce9",
    "url": "/admin/static/css/main.b196d443.chunk.css"
  },
  {
    "revision": "8bd84a6f5c3c61acd056",
    "url": "/admin/static/js/2.34bacc98.chunk.js"
  },
  {
    "revision": "6397acf4c5cafcd591a770ce33fc3e2f",
    "url": "/admin/static/js/2.34bacc98.chunk.js.LICENSE.txt"
  },
  {
    "revision": "21daa3a09fe019439ce9",
    "url": "/admin/static/js/main.8cbacb53.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);