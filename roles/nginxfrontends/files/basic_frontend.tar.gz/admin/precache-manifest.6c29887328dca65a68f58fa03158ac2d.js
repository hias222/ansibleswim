self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cc572d980e2111e4fd2801f8e6a8e8a7",
    "url": "/admin/index.html"
  },
  {
    "revision": "d53e4f69d22879bafe17",
    "url": "/admin/static/css/main.3beb7c71.chunk.css"
  },
  {
    "revision": "86ab659888be95463adf",
    "url": "/admin/static/js/2.33f160ee.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.33f160ee.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d53e4f69d22879bafe17",
    "url": "/admin/static/js/main.ccece599.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);