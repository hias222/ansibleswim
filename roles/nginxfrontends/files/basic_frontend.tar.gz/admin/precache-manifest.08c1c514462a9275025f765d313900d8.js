self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "03b1b5738f3657af6157dcc38ca708b9",
    "url": "/admin/index.html"
  },
  {
    "revision": "adb21170eba987b595d8",
    "url": "/admin/static/css/main.aae5a0c2.chunk.css"
  },
  {
    "revision": "29638f4ba4559021b58b",
    "url": "/admin/static/js/2.9a2d64d3.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.9a2d64d3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "adb21170eba987b595d8",
    "url": "/admin/static/js/main.d3cc2563.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);