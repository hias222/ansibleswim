self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f81622dab1fb50a41b69a11f3121563e",
    "url": "/admin/index.html"
  },
  {
    "revision": "3de85f468792fa85d3bc",
    "url": "/admin/static/css/main.9cf91c12.chunk.css"
  },
  {
    "revision": "29638f4ba4559021b58b",
    "url": "/admin/static/js/2.9a2d64d3.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.9a2d64d3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3de85f468792fa85d3bc",
    "url": "/admin/static/js/main.de29f212.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);