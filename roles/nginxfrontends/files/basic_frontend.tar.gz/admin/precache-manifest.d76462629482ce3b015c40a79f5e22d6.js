self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bc0a06e0318fa34ecae7bca0ff85b6b7",
    "url": "/admin/index.html"
  },
  {
    "revision": "9b9ff41abfc2d2a4b006",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "3e91f0878db50a72dfd9",
    "url": "/admin/static/js/2.8d874081.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.8d874081.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9b9ff41abfc2d2a4b006",
    "url": "/admin/static/js/main.55904a60.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);