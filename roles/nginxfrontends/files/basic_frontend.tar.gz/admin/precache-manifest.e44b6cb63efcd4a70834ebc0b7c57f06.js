self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d902610b58203830aa6d32d0c78f41a5",
    "url": "/admin/index.html"
  },
  {
    "revision": "c451c0eec35cc2375c07",
    "url": "/admin/static/css/main.0185252a.chunk.css"
  },
  {
    "revision": "4ee4a5d5e9e8048c098b",
    "url": "/admin/static/js/2.701e1b38.chunk.js"
  },
  {
    "revision": "89a1b2dcd30c03705b2bceeb141b76b6",
    "url": "/admin/static/js/2.701e1b38.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c451c0eec35cc2375c07",
    "url": "/admin/static/js/main.3f82dc42.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);