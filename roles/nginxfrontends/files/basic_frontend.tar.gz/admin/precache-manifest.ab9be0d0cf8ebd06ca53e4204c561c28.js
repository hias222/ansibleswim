self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f31fee51b9f470d79643c56a75f9080d",
    "url": "/admin/index.html"
  },
  {
    "revision": "afcb1721baf8a180baf3",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "1f8e9bed8d9f2d70042d",
    "url": "/admin/static/js/2.f005e911.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.f005e911.chunk.js.LICENSE.txt"
  },
  {
    "revision": "afcb1721baf8a180baf3",
    "url": "/admin/static/js/main.bf40a624.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);