self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "57639c9798b80598e7e35fcb0e4db373",
    "url": "/admin/index.html"
  },
  {
    "revision": "23513a87ac5dc6022afd",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "6dabb63d8dc688add15b",
    "url": "/admin/static/js/2.59bdd360.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.59bdd360.chunk.js.LICENSE.txt"
  },
  {
    "revision": "23513a87ac5dc6022afd",
    "url": "/admin/static/js/main.867c85cd.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);