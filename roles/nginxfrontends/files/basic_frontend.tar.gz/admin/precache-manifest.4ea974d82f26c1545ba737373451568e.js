self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "58816f88dc0f7b2f84a38e8f1cee142f",
    "url": "/admin/index.html"
  },
  {
    "revision": "80a7ff55f1a9976b4cd6",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "32a2304513c1371daa8c",
    "url": "/admin/static/js/2.fb15e974.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.fb15e974.chunk.js.LICENSE.txt"
  },
  {
    "revision": "80a7ff55f1a9976b4cd6",
    "url": "/admin/static/js/main.e538c9bb.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);