self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "decb8223cf9a0ff95c207d24f91d21cf",
    "url": "/admin/index.html"
  },
  {
    "revision": "15df0c24dca6733faca9",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "b81fbe6858db0d33fdf3",
    "url": "/admin/static/js/2.b588c8da.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.b588c8da.chunk.js.LICENSE.txt"
  },
  {
    "revision": "15df0c24dca6733faca9",
    "url": "/admin/static/js/main.affe5a0f.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);