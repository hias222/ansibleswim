self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ca19361dc8bd6619717ad1e2f835729e",
    "url": "/admin/index.html"
  },
  {
    "revision": "cedfb5d62afed5554ef5",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "6dabb63d8dc688add15b",
    "url": "/admin/static/js/2.59bdd360.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.59bdd360.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cedfb5d62afed5554ef5",
    "url": "/admin/static/js/main.b1f156cc.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);