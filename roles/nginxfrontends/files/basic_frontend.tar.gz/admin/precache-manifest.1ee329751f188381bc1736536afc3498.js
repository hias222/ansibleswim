self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "aef179ed17c87d521ecc18b63b707b58",
    "url": "/admin/index.html"
  },
  {
    "revision": "2a7125de9c293c99e36c",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "32a2304513c1371daa8c",
    "url": "/admin/static/js/2.fb15e974.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.fb15e974.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2a7125de9c293c99e36c",
    "url": "/admin/static/js/main.b159767a.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);