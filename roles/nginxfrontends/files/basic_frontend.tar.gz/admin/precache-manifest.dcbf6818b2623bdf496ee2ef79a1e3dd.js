self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5f7a9a8f3dd3a3dc5b7f2aaca52dd3b2",
    "url": "/admin/index.html"
  },
  {
    "revision": "3ab1bf191175e1ecef35",
    "url": "/admin/static/css/main.82ae08d6.chunk.css"
  },
  {
    "revision": "7b6c63ab2ecd0f1f2040",
    "url": "/admin/static/js/2.dde30e6c.chunk.js"
  },
  {
    "revision": "a70606b416d3e2b380e32a9dc6b4be9d",
    "url": "/admin/static/js/2.dde30e6c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3ab1bf191175e1ecef35",
    "url": "/admin/static/js/main.87cd71ca.chunk.js"
  },
  {
    "revision": "9e907309681cf91dd0a8",
    "url": "/admin/static/js/runtime-main.e2d1bdb9.js"
  }
]);